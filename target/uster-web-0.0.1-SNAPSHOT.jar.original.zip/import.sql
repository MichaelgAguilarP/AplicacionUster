INSERT INTO Vehiculos (id,Brand,Model,Plate,license) VALUES (1, 'Porsche', '911 Gt', 'PD568S','A');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (2, 'Ferrari ', ' V-1', 'PD568W','B');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (3, 'Audi ', 'C4', 'PD5ZXZS','C');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (4, 'Toyota ', 'Hilux', 'SDSDSDS','D');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (5, 'Chevrolet ', 'Corsa', 'DJGD45','D');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (6, 'Kia ', 'Sportage', '656DSS','D');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (7, 'Hyundai ', 'Tucson', 'SDSDSDSD','A');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (8, 'Ford ', 'Ranger', 'AUPSHJ5','B');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (9, 'Chrysler ', 'Neon', 'SDSDSDSH','A');
INSERT INTO Vehiculos (id,Brand,Model,Plate,License) VALUES (10, 'Suzuki ', 'Dzire', '656SDS6D5','C');

INSERT INTO Drivers (id,name,surname,license) VALUES (1,'Robert ', 'Lopez','A');
INSERT INTO Drivers (id,name,surname,license) VALUES (2,'Emilio ', 'Vera','A');
INSERT INTO Drivers (id,name,surname,license) VALUES (3,'Carlos ', 'Robles','B');
INSERT INTO Drivers (id,name,surname,license) VALUES (4,'Eduardo ', 'Alvarez','B');
INSERT INTO Drivers (id,name,surname,license) VALUES (5,'Enrique', 'Ruiz','C');
INSERT INTO Drivers (id,name,surname,license) VALUES (6,'Francisco', 'Valladares','C');
INSERT INTO Drivers (id,name,surname,license) VALUES (7,'Octabio', 'Perez','D');
INSERT INTO Drivers (id,name,surname,license) VALUES (8,'Martin', 'Alvarado','D');
INSERT INTO Drivers (id,name,surname,license) VALUES (9,'Gustavo', 'Lopez','A');
INSERT INTO Drivers (id,name,surname,license) VALUES (10,'SAEL', 'Pow','B');

INSERT INTO Trips (id,date,trip_id,trip_id1) VALUES (1,NOW(),1,1);
INSERT INTO Trips (id,date,trip_id,trip_id1) VALUES (2,NOW(),2,1);